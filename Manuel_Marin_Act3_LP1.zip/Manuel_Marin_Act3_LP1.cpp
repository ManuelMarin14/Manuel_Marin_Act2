/******************************************************************************

Manuel Marin Sanchez
calculo de RFC lenguaje de Programacion 1 
15/04/2025

*******************************************************************************/
#include <iostream>
#include <string>
#include <vector>
#include <algorithm> // Para transformar a mayúsculas
using namespace std;

class RFCGenerator {
private:
    string nombre, apellidoPaterno, apellidoMaterno;
    int dia, mes, anio;

    // Lista de palabras prohibidas (ejemplos comunes)
    const vector<string> palabrasProhibidas = {
        "PEDO", "MAMON", "PUTA", "COGE", "COJA",
        "VERGA", "PENE", "PITO", "WEY", "BUEY",
        "CACA", "CAGO", "KAKA", "PIS", "MEON"
    };

    // Método para obtener la primera vocal interna
    char getPrimeraVocal(const string &str) {
        for (size_t i = 1; i < str.length(); ++i) {
            char c = toupper(str[i]);
            if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                return c;
            }
        }
        return 'X'; // Si no encuentra vocal
    }

    // Método para verificar palabras inconvenientes
    bool esPalabraInconveniente(const string &rfc) {
        if (rfc.length() < 4) return false;
        
        string primeros4 = rfc.substr(0, 4);
        for (const auto& palabra : palabrasProhibidas) {
            if (primeros4.find(palabra) != string::npos) {
                return true;
            }
        }
        return false;
    }

public:
    void capturarDatos() {
        cout << "Introduce tu nombre: ";
        getline(cin, nombre);
        cout << "Introduce tu apellido paterno: ";
        getline(cin, apellidoPaterno);
        cout << "Introduce tu apellido materno: ";
        getline(cin, apellidoMaterno);
        cout << "Fecha de nacimiento (solo numeros)\n";
        cout << "Dia: "; cin >> dia;
        cout << "Mes: "; cin >> mes;
        cout << "Anio: "; cin >> anio;
        cin.ignore(); // Limpiar el buffer
    }

    string calcularRFC() {
        string rfc;

        // Primeros 2 caracteres: Primera letra del apellido paterno + primera vocal interna
        rfc += toupper(apellidoPaterno[0]);
        rfc += getPrimeraVocal(apellidoPaterno);

        // 3er carácter: Inicial del apellido materno (o 'X')
        rfc += (!apellidoMaterno.empty()) ? toupper(apellidoMaterno[0]) : 'X';

        // 4to carácter: Inicial del nombre (validación de palabras inconvenientes)
        char inicialNombre = toupper(nombre[0]);
        rfc += inicialNombre;

        // Validar y corregir si es necesario
        if (esPalabraInconveniente(rfc)) {
            cout << "¡Advertencia: Combinación inconveniente detectada! Se reemplazará con 'X'." << endl;
            rfc[3] = 'X'; // Reemplaza la inicial del nombre
        }

        // Fecha: Año (2 últimos dígitos), mes y día
        string anioStr = to_string(anio).substr(2, 2);
        string mesStr = (mes < 10) ? "0" + to_string(mes) : to_string(mes);
        string diaStr = (dia < 10) ? "0" + to_string(dia) : to_string(dia);

        rfc += anioStr + mesStr + diaStr;
        return rfc;
    }
};

int main() {
    RFCGenerator generador;
    generador.capturarDatos();
    string rfc = generador.calcularRFC();
    cout << "Tu RFC sin homoclave es: " << rfc << endl;
    
    return 0;
}