package com.tiendasara.services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tiendasara.models.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
}