package com.tiendasara.models;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Productos")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String descripcion;
    private Double precio;
    private Integer cantidad;

    @ManyToOne
    @JoinColumn(name = "idCategoria") 
    private Category category;

    @ManyToOne
    @JoinColumn(name = "idMarca")     
    private Mark mark;

    private String imagen;

    @Column(name = "CreatedAt")
    private LocalDateTime createdAt;

    // Getters y Setters...
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public Double getPrecio() { return precio; }
    public void setPrecio(Double precio) { this.precio = precio; }
    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }
    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }
    public Mark getMark() { return mark; }
    public void setMark(Mark mark) { this.mark = mark; }
    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}