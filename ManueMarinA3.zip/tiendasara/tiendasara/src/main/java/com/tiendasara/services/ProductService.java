package com.tiendasara.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tiendasara.models.*;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class ProductService {
    @Autowired private ProductRepository productRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private MarkRepository markRepository;

    public List<Product> getAllProducts() { return productRepository.findAll(); }
    
    public Product createProduct(ProductDto dto) {
        Product product = new Product();
        product.setDescripcion(dto.getDescripcion());
        product.setPrecio(dto.getPrecio());
        product.setCantidad(dto.getCantidad());
        product.setImagen(dto.getImagen());
        product.setCreatedAt(LocalDateTime.now());
        product.setCategory(categoryRepository.findById(dto.getIdCategoria()).orElse(null));
        product.setMark(markRepository.findById(dto.getIdMarca()).orElse(null));
        return productRepository.save(product);
    }
    public Product getProductById(Long id) { return productRepository.findById(id).orElse(null); }
    public void deleteProduct(Long id) { productRepository.deleteById(id); }
}