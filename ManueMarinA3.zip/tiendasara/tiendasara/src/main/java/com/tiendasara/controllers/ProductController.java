package com.tiendasara.controllers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.tiendasara.models.*;
import com.tiendasara.services.*;

@Controller
@RequestMapping("/products")
public class ProductController {
    @Autowired private ProductService productService;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private MarkRepository markRepository;

    @GetMapping({"", "/"})
    public String index(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "products/index";
    }
    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("productDto", new ProductDto());
        model.addAttribute("categories", categoryRepository.findAll());
        model.addAttribute("marks", markRepository.findAll());
        return "products/create";
    }
    @PostMapping("/create")
    public String createProduct(@ModelAttribute ProductDto productDto) {
        productService.createProduct(productDto);
        return "redirect:/products";
    }
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/products";
    }
}