package com.tiendasara.services;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tiendasara.models.Mark;

public interface MarkRepository extends JpaRepository<Mark, Long> {
}